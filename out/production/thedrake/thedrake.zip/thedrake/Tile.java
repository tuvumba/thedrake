package thedrake;

public interface Tile {
    // Returns True if tile is empty and you can step on it
    public boolean canStepOn();

    // Returns True if a troop is present on tile
    public boolean hasTroop();
}
