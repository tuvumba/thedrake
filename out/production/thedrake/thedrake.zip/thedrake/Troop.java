package thedrake;

public class Troop {

    private final String name;
    private Offset2D aversPivot;
    private Offset2D reversePivot;

    public Troop(String name, Offset2D aversPivot, Offset2D reversePivot)
    {

        this.name = name;
        this.aversPivot = aversPivot;
        this.reversePivot = reversePivot;
    }
    public Troop(String name, Offset2D pivot)
    {
        this.name = name;
        this.aversPivot = pivot;
        this.reversePivot = pivot;
    }
    public Troop(String name)
    {
        this.name = name;
        this.aversPivot = new Offset2D(1,1);
        this.reversePivot = new Offset2D(1,1);
    }
    public String name()
    {
        return this.name;
    }
    public Offset2D pivot(TroopFace face)
    {
        return (face.name().equals("AVERS") ? aversPivot : reversePivot);
    }
}
